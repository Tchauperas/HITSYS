import Navbar from "./Navbar";

const ContasPagar = () => {
  return (
    <div>
      <Navbar />
      <h1>Contas a Pagar</h1>
    </div>
  );
};

export default ContasPagar;
