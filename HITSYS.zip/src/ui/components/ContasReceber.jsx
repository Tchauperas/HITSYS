import Navbar from "./Navbar";

const ContasReceber = () => {
  return (
    <div>
      <Navbar />
      <h1>Contas a receber</h1>
    </div>
  );
};

export default ContasReceber;
