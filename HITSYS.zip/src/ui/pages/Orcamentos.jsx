import Navbar from "../components/Navbar"

const Orcamentos = () => {
    return (
        <div>
            <Navbar/>
            <h1>Orçamentos</h1>
        </div>
    )
}

export default Orcamentos